Tensorflow original implementatation of Rendezvous (published in Medical Image Analysis 2022)
