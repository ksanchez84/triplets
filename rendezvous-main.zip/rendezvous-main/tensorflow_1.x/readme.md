Tensorflow low-level implementatation of Rendezvous
