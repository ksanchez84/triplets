Tensorflow keras high-level implementatation of Rendezvous
